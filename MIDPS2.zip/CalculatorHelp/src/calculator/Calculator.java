package calculator;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JToggleButton;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import java.awt.Rectangle;
import java.awt.Component;
import javax.swing.BoxLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.GridLayout;

public class Calculator {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculator window = new Calculator();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Calculator() {
		initialize();
	}
	
	private double var1 = 0;
	private double var2 = 0;
	private double varDot = .0D;
	private double nums = 0;
	private String result = "";
	
	private byte option = -1;
	private static final byte NONE = -1;
	private static final byte EQUAL = 0;
	private static final byte DIVIDE = 1;
	private static final byte MULTIPLY = 2;
	private static final byte SUBTRACT = 3;
	private static final byte ADD = 4;
	private static final byte POW = 5;
	private static final byte SQRT = 6;
	private static final byte DOT = 7;
	private boolean flag = false;
	
	public void func1(double d1)
	{
		if(option == NONE || option == EQUAL)
		{
			var1 = (var1)*10+d1;
			String resultlocal = "" + var1;
			result = resultlocal;
			textField.setText(result);
			System.out.println(var1);
		}
		else if(option == DOT)
		{
			varDot = 0;
			d1 = d1/Math.pow(10, nums++);
			var1 = (var1)+d1;
			String resultlocal = "" + var1;
			result = resultlocal;
			textField.setText(result);
			System.out.println(var1);
		}
		else
		{
			var2 = (var2)*10+d1;
			String resultlocal = "" + var2;
			result = resultlocal;
			textField.setText(result);
			System.out.println("var2: " + var2);
		}
	}
	
	public void func_result()
	{
		String resultlocal = "" + var1;
		result = resultlocal;
		textField.setText(result);
		flag = true;
	}
	
	public void resetOptions()
	{
		if(option!=NONE)
		{
			option = NONE;
			var1 = 0;
			var2 = 0;
			flag = false;
		}
	}
	
	public void func2(byte b1)
	{
		nums = 0;
		option = b1;
		var2 = 0;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 248, 321);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(10, 11, 222, 20);
		textField.setText("0");
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("7");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func1(7);
			}
		});
		btnNewButton.setBounds(10, 42, 47, 40);
		frame.getContentPane().add(btnNewButton);
		
		JButton button = new JButton("8");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func1(8);
			}
		});
		button.setBounds(60, 42, 49, 40);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("9");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func1(9);
			}
		});
		button_1.setBounds(111, 42, 45, 40);
		frame.getContentPane().add(button_1);
		
		JButton button_2 = new JButton("/");
		button_2.setBounds(161, 42, 70, 40);
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func2(DIVIDE);
			}
		});
		frame.getContentPane().add(button_2);
		
		JButton btnMul = new JButton("*");
		btnMul.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func2(MULTIPLY);
			}
		});
		btnMul.setBounds(161, 93, 70, 40);
		frame.getContentPane().add(btnMul);
		
		JButton btnSub = new JButton("-");
		btnSub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func2(SUBTRACT);
			}
		});
		btnSub.setBounds(161, 144, 70, 40);
		frame.getContentPane().add(btnSub);
		
		JButton btnAdd = new JButton("+");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func2(ADD);
			}
		});
		btnAdd.setBounds(161, 195, 70, 40);
		frame.getContentPane().add(btnAdd);
		
		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func1(4);
			}
		});
		btn4.setBounds(10, 93, 47, 40);
		frame.getContentPane().add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func1(5);
			}
		});
		btn5.setBounds(60, 93, 49, 40);
		frame.getContentPane().add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func1(6);
			}
		});
		btn6.setBounds(111, 93, 45, 40);
		frame.getContentPane().add(btn6);
		
		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func1(1);
			}
		});
		btn1.setBounds(10, 144, 47, 40);
		frame.getContentPane().add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func1(2);
			}
		});
		btn2.setBounds(60, 144, 49, 40);
		frame.getContentPane().add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func1(3);
			}
		});
		btn3.setBounds(111, 144, 45, 40);
		frame.getContentPane().add(btn3);
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				func1(0);
			}
		});
		btn0.setBounds(60, 195, 49, 40);
		frame.getContentPane().add(btn0);
		
		JButton btnNewButton_1 = new JButton("C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				var1 = 0;
				var2 = 0;
				option = -1;
				textField.setText("0");
				frame.getContentPane().add(textField);
			}
		});
		btnNewButton_1.setBounds(111, 195, 45, 40);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("=");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				switch(option)
				{
				case ADD:
					var1+=var2;
					break;
				case DIVIDE:
					var1/=var2;
					break;
				case MULTIPLY:
					var1*=var2;
					break;
				case SUBTRACT:
					var1-=var2;
					break;
				case POW:
					var1 = Math.pow(var1, var2);
					break;
				case SQRT:
					var1 = Math.sqrt(var1);
				}
				func_result();
			}
		});
		btnNewButton_2.setBounds(10, 246, 99, 39);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnPow = new JButton("P");
		btnPow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				func2(POW);
			}
		});
		btnPow.setBounds(111, 246, 45, 39);
		frame.getContentPane().add(btnPow);
		
		JButton sqrt = new JButton("SQRT");
		sqrt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				func2(SQRT);
				var1 = Math.sqrt(var1);
				func_result();
			}
		});
		sqrt.setBounds(161, 246, 71, 39);
		frame.getContentPane().add(sqrt);
		
		JButton btnDot = new JButton(".");
		btnDot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				option = DOT;
				nums++;
			}
		});
		btnDot.setBounds(10, 195, 47, 40);
		frame.getContentPane().add(btnDot);
	}
}