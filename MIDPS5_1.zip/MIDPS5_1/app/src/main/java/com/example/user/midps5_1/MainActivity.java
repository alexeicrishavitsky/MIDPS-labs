package com.example.user.midps5_1;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener{


    private TextView txt_msvph;
    private SensorManager mSMan;
    private Sensor mRotationV, mAccelerometer, mMagnetometer;
    float rMat[] = new float[9];
    float[] orientation = new float[9];
    private float[] mLastAccelerometer = new float[3];
    private float[] mLastMagnetometer = new float[3];
    private boolean haveSensor = false;
    private boolean haveSensor2 = false;
    private boolean mLastAccelerometerSet = false;
    private boolean mLastMagnetometerSet = false;
    private MediaPlayer geiger;
    private String[] perms = {"android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.INTERNET"};

    static final float NS2S = 1.0f / 1000000000.0f;
    private double initialX;
    private double initialZ;
    private double posX, posZ;
    private int period = 25;

    private LocationListener locationListener;
    private LocationManager locationManager;

    @Override
    @TargetApi(Build.VERSION_CODES.N_MR1)
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        geiger = MediaPlayer.create(MainActivity.this, R.raw.geiger);

        mSMan = (SensorManager) getSystemService(SENSOR_SERVICE);
        txt_msvph = (TextView) findViewById(R.id.txt_msvph);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                double msx = 0.0D;
                double msz = 0.0D;
                double ms = 0;

                if(initialX == 0)
                {
                    initialX = (location.getLatitude()*1000000)%1000000;
                }
                posX = (location.getLatitude()*1000000)%1000000 - (int)initialX; //20

                if(initialZ == 0)
                {
                    initialZ = (location.getLongitude()*1000000)%1000000;
                }
                posZ = (location.getLongitude()*1000000)%1000000 - (int)initialZ; //-70

                msx = posX/50;
                msz = posZ/50;

                if(msx<0)
                {
                    msx*=-1;
                }
                if(msz<0)
                {
                    msz*=-1;
                }

                ms+=(msx+msz);

                //txt_msvph.setText("X:"+posX + " Z:" + posZ);
                txt_msvph.setText((int)ms +"." + (int)(ms*100)%100+" mSv/h");

                if(ms >= 0.5D)
                {
                    period = 25;
                }

                if(ms >= 1)
                {
                    period = 20;
                }

                if(ms >= 1.5D)
                {
                    period = 17;
                }

                if(ms >= 2D)
                {
                    period = 15;
                }

                if(ms >= 2.5D)
                {
                    period = 12;
                }

                if(ms >= 3.1D)
                {
                    period = 10;
                }

                if(ms >= 4D)
                {
                    period = 5;
                }

                if(ms >= 8D)
                {
                    period = 2;
                }

                if((new Random()).nextInt(period) == 0)
                {
                    if(geiger.isPlaying())
                    {
                        geiger.seekTo(0);
                    }
                    else
                        geiger.start();
                }
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        };

        if(shouldAskPermission()) {
            requestPermissions(perms, 1);
        }else {
            configureButton();
        }

        //start();
    }

    private boolean shouldAskPermission(){
        return(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
    }

    private void configureButton()
    {
       locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10, 0, locationListener);
    }

    public void start()
    {
        if(mSMan.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) == null)
        {
            if(mSMan.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) == null || mSMan.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) == null)
            {
                noSensorAlert();
            }
            else
            {
                mAccelerometer = mSMan.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                mMagnetometer = mSMan.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
                haveSensor = mSMan.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_UI);
                haveSensor2 = mSMan.registerListener(this, mMagnetometer, SensorManager.SENSOR_DELAY_UI);
            }
        }
        else
        {
            mRotationV = mSMan.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            haveSensor = mSMan.registerListener(this, mRotationV, SensorManager.SENSOR_DELAY_UI);
        }
    }

    public void noSensorAlert()
    {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setMessage("Your device is shit, flush it in the toilet!").setCancelable(false)
                .setNegativeButton("Close", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        finish();
                    }
                });

    }

    public void stop()
    {
        if(haveSensor&&haveSensor2)
        {
            mSMan.unregisterListener(this, mAccelerometer);
            mSMan.unregisterListener(this, mMagnetometer);
        }
        else if(haveSensor)
        {
            mSMan.unregisterListener(this, mRotationV);
        }
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        stop();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        start();
    }

    final float alpha = 0.8F;
    private float[] gravity = new float[3];


    @Override
    public void onSensorChanged(SensorEvent event) {
        Random rand = new Random();

        configureButton();
        //txt_msvph.setText((int)ms +"." + (int)(ms*100)%100+" mSv/h");

        if(rand.nextInt(period) == 0)
        {
            if(geiger.isPlaying())
            {
                geiger.seekTo(0);
            }
            else
                geiger.start();
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}